package behavioral.chainOfResponsibility.sample;

public enum Topic {
	NO_HELP_TOPIC,
	PRINT_TOPIC,
	PAPER_ORIENTATION_TOPIC,
	APPLICATION_TOPIC
}
