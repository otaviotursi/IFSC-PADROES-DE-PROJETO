package behavioral.strategy.sample;

public interface Discounter {
	double applyDiscount(double amount);
}
