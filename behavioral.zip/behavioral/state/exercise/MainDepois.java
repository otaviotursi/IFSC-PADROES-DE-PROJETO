package behavioral.state.exercise;

public class MainDepois {

	public static void main(String[] args) {
		Robot robot = new Robot();
		robot.walk();
		robot.walk();
		robot.cook();
		robot.off();
		robot.walk();
		robot.off();
		robot.walk();
		robot.off();
		robot.cook();

	}
}
