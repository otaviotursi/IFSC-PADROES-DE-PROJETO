package behavioral.state.sample;

public interface State {

	void changeChannel(int channel);
	
}