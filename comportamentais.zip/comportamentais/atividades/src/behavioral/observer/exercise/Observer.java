package behavioral.observer.exercise;

public interface Observer {
 
	void Update(WeatherData data);
	
}
