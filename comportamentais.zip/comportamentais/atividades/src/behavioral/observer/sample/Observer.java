package behavioral.observer.sample;

public interface Observer {
 
	void Update(Subject theChangedSubject);
	
}
