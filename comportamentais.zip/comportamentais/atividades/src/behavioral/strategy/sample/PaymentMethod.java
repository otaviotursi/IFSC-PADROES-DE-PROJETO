package behavioral.strategy.sample;

public interface PaymentMethod {
	boolean pay(double value);
}
