package structurals.adapter;

public class Point {
	
	public Coord X() {
		return null;
	}
	
	public Coord Y() {
		return null;
	}
}
