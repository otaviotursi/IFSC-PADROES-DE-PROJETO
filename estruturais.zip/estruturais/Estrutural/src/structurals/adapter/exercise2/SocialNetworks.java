package structurals.adapter.exercise2;

public interface SocialNetworks {

	public void Share(String string);
}
