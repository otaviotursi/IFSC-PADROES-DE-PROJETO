package structurals.adapter.exercise2;


public class Facebook {

	public void updateStatus(String msg) {
		System.out.println("Facebook: " + msg);
	}

}
