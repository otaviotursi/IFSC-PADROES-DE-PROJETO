package structurals.adapter.exercise2;

public class Twitter {

	
	public void send(String msg) {
        System.out.println("Twitter: "+ msg);
    }
	
}
