package structurals.adapter.exercise1;

public interface Shape {

	public void draw(int x1, int y1, int x2, int y2);

}
