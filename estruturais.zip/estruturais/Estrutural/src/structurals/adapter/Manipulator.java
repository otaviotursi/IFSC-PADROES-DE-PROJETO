package structurals.adapter;

public class Manipulator {

}
