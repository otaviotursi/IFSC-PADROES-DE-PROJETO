package structurals.adapter;

public class TextView {
	
	
	void GetOrigin(Coord x, Coord y) {
		
	}
	
	void GetExtent(Coord width, Coord height){
		
	}
	
	public boolean IsEmpty() {
		return true;
	}
}
