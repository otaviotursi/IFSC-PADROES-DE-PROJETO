package structurals.composite;

public class Bus extends CompositeEquipament{

	protected Bus(String name) {
		super(name);
	}

}
