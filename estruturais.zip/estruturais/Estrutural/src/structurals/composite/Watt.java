package structurals.composite;

public class Watt {

}
