package structurals.composite.exercise;

public class Manager extends CompositeEmployee{
	
	public Manager(int codigo, String nome, String cargo) {
		super(codigo, nome, cargo);
	}
}
