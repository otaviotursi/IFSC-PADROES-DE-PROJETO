package structurals.composite.exercise;

public class Intern extends CompositeEmployee{

	CompositeEmployee comp;

	public Intern(int codigo, String nome, String cargo) {
		super(codigo, nome, cargo);
	}

}
