package structurals.decorator;

public class TextView extends VisualComponent{

	// other fields
	
	@Override
	public void Draw() {
		// implementation
		
	}

	@Override
	public void Resize() {
		// implementation
	}

}
