package structurals.decorator.exercise;

public interface FonteDeDados {
    String resultado();
}
